﻿
using Job.EF;
using Job.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Job.Controllers
{
    [Authorize(Roles = "company")]
    public class CompanyController : Controller
    {
        private readonly AppDbContext _context;

        public CompanyController(AppDbContext context)
        {
            _context = context;
        }

        // Company Dashboard
        public IActionResult Dashboard()
        {
            var userIdValue = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdValue, out int userId))
                return RedirectToAction("Login", "Account");

            var user = _context.Users.Find(userId);

            if (user == null)
                return NotFound();


            // Find Logged-in Company's Profile
            var company = _context.Companies
                .FirstOrDefault(c => c.UserId == userId);

            // Total Job Posts Count
            ViewBag.JobPostCount = company == null
                ? 0
                : _context.CompanyJobPosts.Count(j => j.CompanyId == company.CompanyId);

            return View(user);
        }

        // Display Company Job Posts and Load Post for Editing
        [HttpGet]
        public async Task<IActionResult> ManageJobs(int? editId)
        {
            var userIdValue = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdValue, out int userId))
                return RedirectToAction("Login", "Account");

            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.UserId == userId);

            if (company == null)
                return NotFound();

            await LoadJobPosts(company.CompanyId);
            await LoadJobCategories();

            // Load Selected Post for Editing
            if (editId.HasValue)
            {
                var post = await _context.CompanyJobPosts
                    .FirstOrDefaultAsync(j => j.JobPostId == editId.Value && j.CompanyId == company.CompanyId);

                if (post == null)
                    return NotFound();

                return View(post);
            }

            return View(new CompanyJobPost());
        }

        // Create or Update Job Post
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ManageJobs(CompanyJobPost model)
        {
            var userIdValue = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdValue, out int userId))
                return RedirectToAction("Login", "Account");

            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.UserId == userId);

            if (company == null)
                return NotFound();

            // Validate Category
            bool categoryExists = await _context.JobCategories
                .AnyAsync(c => c.CategoryId == model.CategoryId);

            if (!categoryExists)
                ModelState.AddModelError(nameof(model.CategoryId), "Please select a valid category.");

            if (!ModelState.IsValid)
            {
                await LoadJobPosts(company.CompanyId);
                await LoadJobCategories();
                return View(model);
            }

            // Create New Job Post
            if (model.JobPostId == 0)
            {
                model.CompanyId = company.CompanyId;
                _context.CompanyJobPosts.Add(model);

                TempData["Message"] = "Job post created successfully!";
            }
            else
            {
                // Find Existing Post Belonging to Logged-in Company
                var existingPost = await _context.CompanyJobPosts
                    .FirstOrDefaultAsync(j => j.JobPostId == model.JobPostId && j.CompanyId == company.CompanyId);

                if (existingPost == null)
                    return NotFound();

                // Update Job Post Information
                existingPost.CategoryId = model.CategoryId;
                existingPost.JobTitle = model.JobTitle;
                existingPost.JobType = model.JobType;
                existingPost.Vacancy = model.Vacancy;
                existingPost.Location = model.Location;
                existingPost.Salary = model.Salary;
                existingPost.ExperienceRequired = model.ExperienceRequired;
                existingPost.ApplicationDeadline = model.ApplicationDeadline;
                existingPost.Description = model.Description;
                existingPost.PostStatus = model.PostStatus;

                TempData["Message"] = "Job post updated successfully!";
            }

            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(ManageJobs));
        }

        // Delete Job Post
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteJobPost(int id)
        {
            var userIdValue = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdValue, out int userId))
                return RedirectToAction("Login", "Account");

            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.UserId == userId);

            if (company == null)
                return NotFound();

            var post = await _context.CompanyJobPosts
                .FirstOrDefaultAsync(j => j.JobPostId == id && j.CompanyId == company.CompanyId);

            if (post == null)
                return NotFound();

            // Check Existing Applications
            bool hasApplications = await _context.JobApplications
                .AnyAsync(a => a.JobPostId == id);

            if (hasApplications)
            {
                TempData["Message"] = "This job post has applications and cannot be deleted.";
                return RedirectToAction(nameof(ManageJobs));
            }

            _context.CompanyJobPosts.Remove(post);
            await _context.SaveChangesAsync();

            TempData["Message"] = "Job post deleted successfully!";

            return RedirectToAction(nameof(ManageJobs));
        }

        // Load Company's Job Posts
        private async Task LoadJobPosts(int companyId)
        {
            ViewBag.JobPosts = await _context.CompanyJobPosts
                .AsNoTracking()
                .Where(j => j.CompanyId == companyId)
                .OrderByDescending(j => j.JobPostId)
                .ToListAsync();
        }

        // Load Job Categories for Dropdown
        private async Task LoadJobCategories()
        {
            ViewBag.JobCategories = new SelectList(
                await _context.JobCategories.AsNoTracking().ToListAsync(),
                "CategoryId",
                "CategoryName"
            );
        }
    }
}
