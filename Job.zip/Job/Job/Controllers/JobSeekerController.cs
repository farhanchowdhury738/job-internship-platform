﻿
using Job.EF;
using Job.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Job.Controllers
{
    [Authorize(Roles = "job_seeker")]
    public class JobSeekerController : Controller
    {
        private readonly AppDbContext _context;

        public JobSeekerController(AppDbContext context)
        {
            _context = context;
        }

        // Job Seeker Dashboard
        public async Task<IActionResult> Dashboard()
        {
            var userIdValue = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdValue, out int userId))
                return RedirectToAction("Login", "Account");

            var user = await _context.Users.FindAsync(userId);

            if (user == null)
                return NotFound();

            // Total Applied Jobs Count
            ViewBag.AppliedJobsCount = await _context.JobApplications.CountAsync(a => a.UserId == userId);

            // Total Projects Count
            ViewBag.ProjectsCount = await _context.JobSeekerProjects.CountAsync(p => p.UserId == userId);

            return View(user);
        }

        // Display Applied Jobs
        public async Task<IActionResult> AppliedJobs()
        {
            var userIdValue = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdValue, out int userId))
                return RedirectToAction("Login", "Account");

            var applications = await _context.JobApplications
                .AsNoTracking()
                .Include(a => a.CompanyJobPost)
                .ThenInclude(j => j!.Company)
                .Where(a => a.UserId == userId)
                .OrderByDescending(a => a.AppliedAt)
                .ToListAsync();

            return View(applications);
        }


        // Display Job Seeker Projects
        public async Task<IActionResult> MyProjects()
        {
            var userIdValue = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdValue, out int userId))
                return RedirectToAction("Login", "Account");

            var projects = await _context.JobSeekerProjects
                .AsNoTracking()
                .Where(p => p.UserId == userId)
                .OrderByDescending(p => p.ProjectId)
                .ToListAsync();

            return View(projects);
        }


        // Edit Project - GET
        [HttpGet]
        public async Task<IActionResult> EditProject(int id)
        {
            var userIdValue = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdValue, out int userId))
                return RedirectToAction("Login", "Account");

            var project = await _context.JobSeekerProjects
                .FirstOrDefaultAsync(p => p.ProjectId == id && p.UserId == userId);

            if (project == null)
                return NotFound();

            return View(project);
        }

        // Edit Project - POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditProject(int id, JobSeekerProject model)
        {
            var userIdValue = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdValue, out int userId))
                return RedirectToAction("Login", "Account");

            if (id != model.ProjectId)
                return BadRequest();

            if (!ModelState.IsValid)
                return View(model);

            var project = await _context.JobSeekerProjects
                .FirstOrDefaultAsync(p => p.ProjectId == id && p.UserId == userId);

            if (project == null)
                return NotFound();

            project.ProjectTitle = model.ProjectTitle;
            project.Description = model.Description;
            project.LiveUrl = model.LiveUrl;

            await _context.SaveChangesAsync();

            TempData["Message"] = "Project updated successfully!";
            TempData["MessageType"] = "success";

            return RedirectToAction(nameof(MyProjects));
        }

        // Create Project - GET
        [HttpGet]
        public IActionResult CreateProject()
        {
            return View();
        }

        // Create Project - POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateProject(JobSeekerProject project)
        {
            var userIdValue = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdValue, out int userId))
                return RedirectToAction("Login", "Account");

            if (!ModelState.IsValid)
                return View(project);

            project.UserId = userId;
            _context.JobSeekerProjects.Add(project);
            await _context.SaveChangesAsync();

            TempData["Message"] = "Project added successfully!";
            TempData["MessageType"] = "success";

            return RedirectToAction(nameof(MyProjects));
        }

        // Delete Project
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteProject(int id)
        {
            var userIdValue = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdValue, out int userId))
                return RedirectToAction("Login", "Account");

            var project = await _context.JobSeekerProjects
                .FirstOrDefaultAsync(p => p.ProjectId == id && p.UserId == userId);

            if (project == null)
                return NotFound();

            _context.JobSeekerProjects.Remove(project);
            await _context.SaveChangesAsync();

            TempData["Message"] = "Project deleted successfully!";
            TempData["MessageType"] = "success";

            return RedirectToAction(nameof(MyProjects));
        }



    }
}
