﻿
using Job.EF;
using Job.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Claims;

namespace Job.Controllers
{
    public class AccountController : Controller
    {
        private readonly AppDbContext _context;

        public AccountController(AppDbContext context)
        {
            _context = context;
        }

        // Register Page
        public IActionResult Register()
        {
            return View();
        }

        // Register Submit
        [HttpPost]
        public async Task<IActionResult> Register(Register model)
        {
            if (ModelState.IsValid)
            {
                string email = model.Email.Trim();

                var exists = _context.Users
                    .Any(u => u.Email == email);

                if (exists)
                {
                    ModelState.AddModelError("Email", "Email already exists.");
                    return View(model);
                }

                User user = new User();

                user.FullName = model.FullName;
                user.Email = email;
                user.PasswordHash = model.Password;
                user.Role = model.Role;

                _context.Users.Add(user);
                await _context.SaveChangesAsync();

                return RedirectToAction("Login");
            }

            return View(model);
        }

        // Login Page
        [HttpGet]
        public IActionResult Login(string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        // Login Submit
        [HttpPost]
        public async Task<IActionResult> Login(Login model, string? returnUrl = null)
        {
            if (ModelState.IsValid)
            {
                string email = model.Email.Trim();

                var user = _context.Users.FirstOrDefault(u => u.Email == email);

                if (user != null && user.PasswordHash == model.Password)
                {
                    var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
                new Claim(ClaimTypes.Name, user.FullName),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim(ClaimTypes.Role, user.Role)
            };

                    var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                    var principal = new ClaimsPrincipal(identity);

                    await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

                    // Return to Previous Page After Login
                    if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                    {
                        return LocalRedirect(returnUrl);
                    }

                    // Redirect Based on User Role
                    if (user.Role == "job_seeker")
                    {
                        return RedirectToAction("Dashboard", "JobSeeker");
                    }
                    else if (user.Role == "company")
                    {
                        return RedirectToAction("Dashboard", "Company");
                    }
                }

                ModelState.AddModelError("", "Invalid Email or Password.");
            }

            ViewData["ReturnUrl"] = returnUrl;
            return View(model);
        }



        // Logout
        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(
                CookieAuthenticationDefaults.AuthenticationScheme
            );

            return RedirectToAction("Login");
        }
    }
}
